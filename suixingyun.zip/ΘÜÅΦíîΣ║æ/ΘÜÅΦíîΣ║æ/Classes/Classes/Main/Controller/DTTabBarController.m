//
//  DTTabBarController.m
//  随行云
//
//  Created by 鼎拓 on 2017/8/23.
//  Copyright © 2017年 鼎拓信息科技有限公司. All rights reserved.
//

#import "DTTabBarController.h"

#import "DTRecentlyViewController.h"
#import "DTFileViewController.h"
#import "DTPictureViewController.h"
#import "DTOff_lineViewController.h"
#import "DTImage.h"
#import "DTTabBar.h"

@interface DTTabBarController ()
/**
 *  自定义的tabbar
 */
@property (nonatomic, weak) DTTabBar *customTabBar;

@end

@implementation DTTabBarController
+ (void)load{
    UITabBarItem *tabBarItem = [UITabBarItem  appearance];
    //未选中的
    NSMutableDictionary *norAttri = [NSMutableDictionary dictionary];
    norAttri[NSFontAttributeName] = [UIFont systemFontOfSize:14];
    norAttri[NSForegroundColorAttributeName] = [UIColor redColor];
    [tabBarItem setTitleTextAttributes:norAttri forState:UIControlStateNormal];
    //选中的
    NSMutableDictionary *selectAttri = [NSMutableDictionary dictionary];
    selectAttri[NSForegroundColorAttributeName] = [UIColor blueColor];
    [tabBarItem setTitleTextAttributes:selectAttri forState:UIControlStateSelected];
    
}


#pragma mark - 生命周期方法
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // 添加子控制器(4个子控制器)--》自定义控制器--》划分项目文件结构
    [self setupAllChildViewController];
    // 设置tabBar上所有按钮内容
    [self setupAllTitleImageButton];
    // 初始化tabbar
//    [self setupTabbar];
    
//    //设置标签栏文字和图片的颜色,保持图片原样的级别高。
//    self.tabBar.tintColor = [UIColor blueColor];
//    
//    //设置标签栏的颜色
//    self.tabBar.barTintColor = [UIColor whiteColor];
//    
//    //设置标签栏风格(默认高度49)
////    self.tabBar.barStyle = UIBarStyleDefault;//UIBarStyleBlack;
//    
//    //设置初始状态选中的下标
//    self.selectedIndex=2;
}
#pragma mark - 初始化tabbar
//- (void)setupTabbar{
//    DTTabBar *customTabBar = [[DTTabBar alloc] init];
//    customTabBar.frame = self.tabBar.bounds;
//    customTabBar.delegate = self;
//    [self.tabBar addSubview:customTabBar];
//    self.customTabBar=customTabBar;
//    
//    
//}
#pragma mark - 添加所有子控制器(UIViewController)
- (void)setupAllChildViewController {
    // 最近
    DTRecentlyViewController *recentlyVC = [[DTRecentlyViewController alloc] init];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:recentlyVC];
    // 设置控制器的属性(自己的属性最好自己来管理所以先不要在这里设置控制器的类)
    recentlyVC.title = @"最近";
    //    recentlyVC.tabBarItem.image = [UIImage imageNamed:@"tabBar_recently_icon"];
    
    //    nav.title = @"最近";
    //    nav.tabBarItem.title = @"最近";
    //    nav.tabBarItem.image = [UIImage imageNamed:@"tabBar_recently_icon"];
    
    // tabBarVc:会把第0个子控制器的view添加去
    [self addChildViewController:nav];
    
    //文件
    DTFileViewController *fileVC = [[DTFileViewController alloc] init];
    UINavigationController *nav1 = [[UINavigationController alloc] initWithRootViewController:fileVC];
    
    //    nav1.title = @"文件";
    //    nav1.tabBarItem.title = @"文件";
    //    nav1.tabBarItem.image = [UIImage imageNamed:@"tabBar_file_icon"];
    
    [self addChildViewController:nav1];
    //照片
    DTPictureViewController *pictureVC = [[DTPictureViewController alloc] init];
    UINavigationController *nav2 = [[UINavigationController alloc] initWithRootViewController:pictureVC];
    //    nav2.title = @"照片";
    //    nav2.tabBarItem.title = @"照片";
    //    nav2.tabBarItem.image = [UIImage imageNamed:@"tabBar_picture_icon"];
    [self addChildViewController:nav2];
    //离线
    DTOff_lineViewController *off_lineVC = [[DTOff_lineViewController alloc] init];
    UINavigationController *nav3 = [[UINavigationController alloc] initWithRootViewController:off_lineVC];
    //    nav3.title = @"离线";
    //    nav3.tabBarItem.title = @"离线";
    //    nav3.tabBarItem.image = [UIImage imageNamed:@"tabBar_off_line_icon"];
    
    [self addChildViewController:nav3];
}
#pragma mark - 设置tabBar上所有按钮内容
- (void)setupAllTitleImageButton{
    //最近
    UINavigationController *nav = self.childViewControllers[0];
    nav.tabBarItem.title = @"最近";
    nav.tabBarItem.image = [UIImage imageNamed:@"icon_tab_recent_nor"];
    nav.tabBarItem.selectedImage = [DTImage imageOriginalWithName:@"icon_tab_recent_pre"];
    //文件
    UINavigationController *nav1 = self.childViewControllers[1];
    nav1.tabBarItem.title = @"文件";
    nav1.tabBarItem.image = [UIImage imageNamed:@"icon_tab_cloud_nor"];
    nav1.tabBarItem.selectedImage = [DTImage imageOriginalWithName:@"icon_tab_cloud_pre"];
    //照片
    UINavigationController *nav2 = self.childViewControllers[2];
    nav2.tabBarItem.title = @"照片";
    nav2.tabBarItem.image = [UIImage imageNamed:@"icon_tab_photo_nor"];
    nav2.tabBarItem.selectedImage = [DTImage imageOriginalWithName:@"icon_tab_photo_pre"];
    //离线
    UINavigationController *nav3 = self.childViewControllers[3];
    nav3.tabBarItem.title = @"离线";
    nav3.tabBarItem.image = [UIImage imageNamed:@"icon_tab_offline_nor"];
    nav3.tabBarItem.selectedImage = [DTImage imageOriginalWithName:@"icon_tab_offline_pre"];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
