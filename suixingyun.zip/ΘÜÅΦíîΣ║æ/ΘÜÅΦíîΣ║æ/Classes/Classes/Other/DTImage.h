//
//  DTImage.h
//  随行云
//
//  Created by 鼎拓 on 2017/8/23.
//  Copyright © 2017年 鼎拓信息科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DTImage : UIImage
+ (UIImage *)imageOriginalWithName:(NSString *)imageName;
@end
